/*
 * ---------------------------------------------------------------------------
 * File name: TempType.java
 * Project name: Conversion
 * ---------------------------------------------------------------------------
 * Creator's name and email: Matt Harrison, harrisonms1@etsu.edu
 * Course:  CSCI 1260
 * Creation Date: 3/19/2019
 * ---------------------------------------------------------------------------
 */

public enum TempType
{
	C,
	K,
	F
}
